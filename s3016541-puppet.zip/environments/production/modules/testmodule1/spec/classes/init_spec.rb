require 'spec_helper'
describe 'testmodule1' do
  context 'with default values for all parameters' do
    it { should contain_class('testmodule1') }
  end
end
